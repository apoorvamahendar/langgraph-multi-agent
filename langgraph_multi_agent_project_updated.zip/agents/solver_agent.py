from langchain_core.messages import HumanMessage

def solver_agent(state):
    question = state["question"]
    print(f"SolverAgent received: {question}")
    try:
        result = eval(question)  # Don't use eval in production
        state["solution"] = result
        return {"solution": result}
    except Exception as e:
        return {"error": str(e)}
