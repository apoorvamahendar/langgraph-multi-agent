def verifier_agent(state):
    question = state["question"]
    solution = state.get("solution")
    try:
        correct = eval(question)
        if solution == correct:
            return {"verified": True, "message": "✅ Answer verified as correct."}
        else:
            return {"verified": False, "message": f"❌ Verification failed. Expected {correct} but got {solution}"}
    except Exception as e:
        return {"verified": False, "message": f"Verification error: {str(e)}"}
