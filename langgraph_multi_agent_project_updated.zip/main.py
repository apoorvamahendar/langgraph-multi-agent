import os
from dotenv import load_dotenv
from langgraph.graph import StateGraph, END

from agents.solver_agent import solver_agent
from agents.verifier_agent import verifier_agent

# Load API key
load_dotenv()
os.environ["OPENAI_API_KEY"] = os.getenv("OPENAI_API_KEY")

# Define state schema
state = {
    "question": None,
    "solution": None,
    "verified": None,
    "message": None
}

# Define graph with schema
builder = StateGraph(input_schema=dict)

builder.add_node("Solver", solver_agent)
builder.add_node("Verifier", verifier_agent)

builder.set_entry_point("Solver")
builder.add_edge("Solver", "Verifier")
builder.add_edge("Verifier", END)

app = builder.compile()

# Run the graph
if __name__ == "__main__":
    input_data = {"question": "12 * (5 + 3)"}  # Example question
    result = app.invoke(input_data)
    print("Final Output:")
    print(result)
